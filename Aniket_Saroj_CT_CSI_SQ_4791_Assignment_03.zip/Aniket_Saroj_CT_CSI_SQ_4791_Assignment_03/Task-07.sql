SELECT STRING_AGG(CAST(n AS VARCHAR), '&') AS prime_numbers
FROM Primes;
